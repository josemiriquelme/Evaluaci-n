package ejercicio04;

public class Persona_Main {
	
	public static void main (String [] args) {
		
		
		epublico e1 = new epublico("152423566", "Fernando Mellado Salinas", "Los Laureles 45", 945281947, 780000, "Municipalidad de los Alamos", "Administrativo");
		eprivado e2 = new eprivado("123456787", "Francisco Risopatr�n De Lourdes", "Juan Bosco 1786", 976834616, 6000000, "Comuna Las Condes", "Gerencia");
	
	System.out.println("**********************Empleado publico**************************");
	System.out.println("1. RUN: " + e1.getRun());
	System.out.println("2. Nombre completo: " + e1.getNombreCompleto());
	System.out.println("3. Direcci�n: " + e1.getDirecci�n());
	System.out.println("4. Telefono: " + e1.getTel�fono());
	System.out.println("5. Sueldo: " + e1.getSueldo());
	System.out.println("6. Lugar de trabajo: " + e1.getLugarTrabajo());
	System.out.println("7. Cargo: " + e1.getPuestoTrabajo());
	
	System.out.println("**********************Empleado privado**************************");
	System.out.println("1. RUN: " + e2.getRun());
	System.out.println("2. Nombre completo: " + e2.getNombreCompleto());
	System.out.println("3. Direcci�n: " + e2.getDirecci�n());
	System.out.println("4. Telefono: " + e2.getTel�fono());
	System.out.println("5. Sueldo: " + e2.getSueldo());
	System.out.println("6. Lugar de trabajo: " + e2.getComunaResidencia());
	System.out.println("7. Cargo: " + e2.getCargo());
	}

}
 