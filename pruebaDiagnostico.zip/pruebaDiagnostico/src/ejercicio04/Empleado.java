package ejercicio04;

public class Empleado {
	
	 private String run;
	 private String nombreCompleto;
	 private String direcci�n;
	 private int tel�fono;
     private long sueldo;
	
     public Empleado() {
		super();
	}

	public Empleado(String run, String nombreCompleto, String direcci�n, int tel�fono, long sueldo) {
		super();
		this.run = run;
		this.nombreCompleto = nombreCompleto;
		this.direcci�n = direcci�n;
		this.tel�fono = tel�fono;
		this.sueldo = sueldo;
	}

	public String getRun() {
		return run;
	}

	public void setRun(String run) {
		this.run = run;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getDirecci�n() {
		return direcci�n;
	}

	public void setDirecci�n(String direcci�n) {
		this.direcci�n = direcci�n;
	}

	public int getTel�fono() {
		return tel�fono;
	}

	public void setTel�fono(int tel�fono) {
		this.tel�fono = tel�fono;
	}

	public long getSueldo() {
		return sueldo;
	}

	public void setSueldo(long sueldo) {
		this.sueldo = sueldo;
	}
     
     
	
	

	
	
	
	

}
