package ejercicio04;

public class eprivado extends Empleado{
	
	String comunaResidencia;
	String cargo;
	
	public eprivado(String run, String nombreCompleto, String direcci�n, int tel�fono, long sueldo) {
		super(run, nombreCompleto, direcci�n, tel�fono, sueldo);}

	public eprivado(String run, String nombreCompleto, String direcci�n, int tel�fono, long sueldo,
			String comunaResidencia, String cargo) {
		super(run, nombreCompleto, direcci�n, tel�fono, sueldo);
		this.comunaResidencia = comunaResidencia;
		this.cargo = cargo;
	}

	public String getComunaResidencia() {
		return comunaResidencia;
	}

	public void setComunaResidencia(String comunaResidencia) {
		this.comunaResidencia = comunaResidencia;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	
}


	
	
	
		
	
	
	