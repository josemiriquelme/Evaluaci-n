package ejercicio04;

public class epublico extends Empleado{
	
	String lugarTrabajo;
	String puestoTrabajo;
	
	public epublico(String run, String nombreCompleto, String direcci�n, int tel�fono, long sueldo) {
		super(run, nombreCompleto, direcci�n, tel�fono, sueldo);
	}
	public epublico(String run, String nombreCompleto, String direcci�n, int tel�fono, long sueldo, String lugarTrabajo,
			String puestoTrabajo) {
		super(run, nombreCompleto, direcci�n, tel�fono, sueldo);
		this.lugarTrabajo = lugarTrabajo;
		this.puestoTrabajo = puestoTrabajo;
	}
	public String getLugarTrabajo() {
		return lugarTrabajo;
	}
	public void setLugarTrabajo(String lugarTrabajo) {
		this.lugarTrabajo = lugarTrabajo;
	}
	public String getPuestoTrabajo() {
		return puestoTrabajo;
	}
	public void setPuestoTrabajo(String puestoTrabajo) {
		this.puestoTrabajo = puestoTrabajo;
	}
	
	
	
	
}
