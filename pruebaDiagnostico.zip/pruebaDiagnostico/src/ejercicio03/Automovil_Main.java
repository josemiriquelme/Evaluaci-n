package ejercicio03;

public class Automovil_Main {
	
	public static void main (String [] args) {
		
		Automovil x = new Automovil("toyota", "city car", 2009, 5000000);
		
		
		
		System.out.println("La marca del auto es: " + x.marca);
		System.out.println("El modelo del auto es: " + x.modelo);
		System.out.println("El auto es del a�o: " + x.a�o);
		System.out.println("El precio inicial del auto es: " + x.precio);
		x.precioFinal();
		
	}

}
