package ejercicio01;

import java.util.Scanner;

public class Tarjeta {
	
	
	int numero_tarjeta;
	int usuario;
	int saldo;
	int descuento;
	
	
	public Tarjeta() {
		super();
	}


	public Tarjeta(int numero_tarjeta, int usuario, int saldo, int descuento) {
		super();
		this.numero_tarjeta = numero_tarjeta;
		this.usuario = usuario;
		this.saldo = saldo;
		this.descuento = descuento;
	}


	public int getNumero_tarjeta() {
		return numero_tarjeta;
	}


	public void setNumero_tarjeta(int numero_tarjeta) {
		this.numero_tarjeta = numero_tarjeta;
	}


	public int getUsuario() {
		return usuario;
	}


	public void setUsuario(int usuario) {
		this.usuario = usuario;
	}


	public int getSaldo() {
		return saldo;
	}


	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}


	public int getDescuento() {
		return descuento;
	}


	public void setDescuento(int descuento) {
		this.descuento = descuento;
	}
	
	
public void crearUsuario(int c,Tarjeta t[]) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("\n Tarjeta N�: " + (c+1));
		t[c].setNumero_tarjeta(c+1);
		System.out.print("Ingrese tipo de usuario ");
		System.out.println("1.-Com�n 2.-TNE 3.-Bip");
		t[c].setUsuario(sc.nextInt());
		System.out.print("Ingrese monto a cargar");
		t[c].setSaldo(sc.nextInt());
		System.out.print("Tiempo de inactividad");
		t[c].setDescuento(sc.nextInt());
	}
	
	
	
	
	}

