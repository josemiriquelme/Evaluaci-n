package ejercicio01;

import java.util.Scanner;
public class Menu {
	public static void main(String[] args) {
		Tarjeta t[] = new Tarjeta[5];
		Scanner sc = new Scanner(System.in);	
		int op=0;
		int c=0;
	do
	{
		System.out.println("         BIOTREN         ");
		System.out.println("*********");
		System.out.println("1.- Crear nuevo usuario  ");
		System.out.println("2.- Abonar a tarjeta     ");
		System.out.println("3.- Descuento por viaje  ");
		System.out.println("4.- Consultar saldo      ");
	System.out.println("5.- Verificar tarjeta    ");
		System.out.println("6.- Salir                \n");
		System.out.println("Ingrese opcion :          ");
		op= sc.nextInt();
		
		switch(op) {
		//Ingreso nuevo usuario
		case 1:	
			t[c] = new Tarjeta();
			t[c].crearUsuario(c, t);
			c++;
			break;
		
		//Abono de dinero	
		case 2:
			System.out.println("Ingrese numero de tarjeta");
			int numero;
			numero = sc.nextInt();
			int abono=0;
			System.out.println("Ingrese abono");
			abono = sc.nextInt();
			
			for(int i=0;i<c;i++)
			{
				if(t[i].getNumero_tarjeta()==numero) {
					t[i].setSaldo(t[i].getSaldo()+abono);
				}
			}
			break;
		
		case 3:
			//descuento por viaje
			System.out.println("Valor del viaje $500");
			System.out.println("Ingrese numero de tarjeta");
			int numero2;
			numero2 = sc.nextInt();
			for(int i=0;i<c;i++) {
				if(t[i].getNumero_tarjeta()==numero2) {
					System.out.println("Su saldo disponible es:");
					if(t[i].getSaldo()>500) {
						t[i].setSaldo(t[i].getSaldo()-500);
						System.out.println("Su saldo restante es :");
						t[i].getSaldo();}
					else
						System.out.println("Su saldo es insuficiente");
				}
			}	
			break;
		case 4:
			//consultar saldo
			System.out.println("Ingrese numero de tarjeta");
			int numero3;
			numero3 = sc.nextInt();
			for(int i=0;i<c;i++)
				if(t[i].getNumero_tarjeta()==numero3)
					System.out.println("Su saldo disponible es :" +t[i].getSaldo());
			break;
		case 5:
			//Verificacion tarjeta activa o inactiva
			System.out.println("Ingrese numero de tarjeta");
			int numero4;
			numero4 = sc.nextInt();
			
			
			break;
		case 6:
			break;
		default:
			System.out.println("Ingrese una opci�n v�lida");
	}
	}while(op!=6);
	}
}
