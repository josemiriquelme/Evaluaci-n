package ejercicio02;


public class Empleado {
	
		
	private String rut;
	private String nombre;
	private String apellidop;
	private String apellidom;
	private String cargo;
	private String direcci�n;
	private int fono;
	private String Email;
	
	public Empleado() {
		super();
	}

	public Empleado(String rut, String nombre, String apellidop, String apellidom, String cargo) { //Metodo 1
		super();
		this.rut = rut;
		this.nombre = nombre;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.cargo = cargo;
	}

	public Empleado(String rut, String apellidop, String apellidom, String direcci�n, int fono, String email) { //Metodo 2
		super();
		this.rut = rut;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.direcci�n = direcci�n;
		this.fono = fono;
		Email = email;
	}
	
	

}